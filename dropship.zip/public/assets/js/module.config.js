const MODULE_CONFIG = {
	pd: [
		'/assets/js/plugins/pd.js',
		'/assets/css/plugins/pd.css'
	],
	hf: [
		'/assets/js/plugins/hf.js',
	]
};