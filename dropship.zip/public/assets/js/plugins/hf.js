$('nav').removeClass('mb-5');
$('nav form').css('visibility', 'hidden');