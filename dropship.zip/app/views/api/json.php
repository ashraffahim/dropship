<?php

header('Content-Type: application/json; charset=utf8mb4');

echo json_encode($data);

?>