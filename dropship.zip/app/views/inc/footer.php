	</main>
	<!-- jQuery -->
	<script src="/libs/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="/libs/popper.js/dist/umd/popper.min.js"></script>
	<script src="/libs/bootstrap/dist/js/bootstrap.min.js"></script>
	<!-- feathericon -->
	<script src="/libs/feather-icons/dist/feather.min.js"></script>
	<script src="/assets/js/plugins/feathericon.js"></script>
	<!-- Theme -->
	<script src="/assets/js/module.config.js"></script>
	<script src="/assets/js/theme.js"></script>
</body>
</html>