<div class="container-fluid">
	<div class="row">
		<div class="col-12 text-center">
			<img src="/assets/img/no-data.png" alt="No Data" height="400">
			<div><span class="text-primary lead">Product not found!</span></div>
		</div>
	</div>
</div>