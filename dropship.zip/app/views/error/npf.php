<div class="container-fluid">
	<div class="row">
		<div class="col-12 text-center">
			<img src="/assets/img/no-data.png" alt="No Data" height="400">
			<div><span class="text-primary lead">I see you're only interested in the exceptionally rare!</span></div>
		</div>
	</div>
</div>