<?php

// Date & Time
date_default_timezone_set('UTC');

// Database constants
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '646862');
define('DB_NAME', 'dropship_db');

// Software
define('DS', DIRECTORY_SEPARATOR);
define('DOMAIN', 'http://menu');
define('BASEDIR', '');
define('DATA', '/data');
define('DATADIR', '..'.DS.'..'.DS.'dropship-seller'.DS.'data');
define('LOGO', 'http://dropship/assets/img/agit-logo-c.png');
define('SITENAME', '');
define('APP_VERSION', '1.0.0');

// User
define('SALES_TEL', '+971556314003');
define('SALES_EMAIL', 'sales@alghaim.com');
define('TECH_EMAIL', 'support@alghaim.com');

?>